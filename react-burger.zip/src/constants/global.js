export const baseUrl = "https://norma.nomoreparties.space/api/";
