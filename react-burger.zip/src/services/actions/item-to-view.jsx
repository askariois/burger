export const OPEN_MODAL = "OPEN_MODAL";
export const CLOSE_MODAL = "CLOSE_MODAL";

export const OPEN_MODAL_ORDER = "OPEN_MODAL_ORDER";
export const CLOSE_MODAL_ORDER = "CLOSE_MODAL_ORDER";
